## Gmail clone

In this project user has to create the clone of the gmail which is a very popular email service provider by google. User needs to login to his gmail account and then had to create the complete interface of it.

> All the images are svg's, gathered by inspecting the gmail website and other's from the [hero icons](https://heroicons.com/) website.

## Tech Used

- HTML
- Tailwind CSS

## Website Link

Below is the link for the Gmail website.

[Gmail Website](https://mail.google.com/)

## Sample Output

![Gmail output](/tailwind/01%20Gmail%20Clone/output/gmailCloneOutput.png)
