## Redbus homepage clone

In this project user has to clone the homepage of the popular website redbus.

The homepage of redbus is not responsive by itself as they have seprate mobile web app for it, so if user wants to make it responsive then they have to think about it by their own.

> All the required assets are given in the **assets** folder.

## Tech Used

- HTML
- CSS

## Website Link

Below is the link for the redbus homepage.

[Redbus Homepage](https://www.redbus.in/)
