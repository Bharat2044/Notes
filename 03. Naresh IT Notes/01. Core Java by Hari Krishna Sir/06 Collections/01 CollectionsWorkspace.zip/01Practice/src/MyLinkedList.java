
public class MyLinkedList {
	
	private int size;
	
	public MyLinkedList() {

	}

}
