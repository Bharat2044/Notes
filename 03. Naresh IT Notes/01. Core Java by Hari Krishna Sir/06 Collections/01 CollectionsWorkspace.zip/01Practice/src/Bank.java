
public class Bank {
	//private BankAccount[] bankAccount = new BankAccount[60];
	//NITCollection coll = new NITCollection();
	NITTable table = new NITTable();
	
	

}
