package com.nit.hk.suncollections;

public class MRComparator {

	public int compareBYDesc(B b1, B b2) {
		return b2.getY() - b1.getY();
	}
}
