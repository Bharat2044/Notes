
public class Company {
	//private Employee[] employee = new Employee[60];
	MyArrayList coll = new MyArrayList();
	

	
}
