package com.nit.hk.specs;

import com.nit.hk.exceptions.InsufficientFundsException;
import com.nit.hk.exceptions.InvalidAmountException;

public interface BankAccount {
	
	public long getAccNum();
	public void deposit(double amt) throws InvalidAmountException;
	public void withdraw(double amt) throws InvalidAmountException, InsufficientFundsException;
	public void currentBalance();
	
}

