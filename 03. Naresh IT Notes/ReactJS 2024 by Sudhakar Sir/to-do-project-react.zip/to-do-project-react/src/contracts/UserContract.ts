export  interface  UserContract
     {
	UserId:string;
	UserName:string;
	Password:string;
	Email:string;
	Mobile:string;
     }
