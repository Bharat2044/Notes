export interface AppointmentContract
     {
	Appointment_Id:number;
	Title:string;
	Description:string;
	Date:Date;
	UserId:string;
     }
     