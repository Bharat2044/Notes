# Circle.py----File Name and Module name
def area():
	r=float(input("Enter Radius of Circle:"))
	print("Area of Circle={}".format(3.14*r**2))