#Square.py----File Name and Module name
def area():
	s=float(input("Enter Side:"))
	print("Area of Square={}".format(s**2))