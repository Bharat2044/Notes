#Rect.py----File Name and Module name
def area():
	print("Enter Length and Breadth:")
	l,b=float(input()),float(input())
	print("Area of Rect={}".format(l*b))
