#Triangle.py----File Name and Module name
def area():
	print("Enter Base and Height of Triangle:")
	b,h=float(input()),float(input())
	print("Area of Triangle={}".format((1/2)*b*h))