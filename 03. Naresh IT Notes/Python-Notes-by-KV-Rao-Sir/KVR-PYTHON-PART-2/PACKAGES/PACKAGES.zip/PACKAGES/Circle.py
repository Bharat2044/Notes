#Circle.py<--File Name and Module Name
def area():
    print("Enter Radius")
    r=float(input())
    ca=3.14*r**2
    print("Area of Circle=",ca)