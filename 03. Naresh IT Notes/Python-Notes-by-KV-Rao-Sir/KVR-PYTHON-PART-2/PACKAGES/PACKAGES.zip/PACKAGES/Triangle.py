#Triangle.py<--File Name and Module name
def area():
    print("Enter Base and Height")
    b,h=float(input()),float(input())
    at=1/2*(b*h)
    print("Area of Triangle=",at)