#Square.py<--File Name and Module Name
def area():
    print("Enter Side")
    s=float(input())
    sa=s**2
    print("Area of Square=",sa)