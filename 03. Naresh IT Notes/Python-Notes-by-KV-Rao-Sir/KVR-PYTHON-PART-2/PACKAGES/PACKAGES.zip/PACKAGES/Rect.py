#Rect.py<--File Name and Module Name
def area():
    print("Enter Length and Breadth")
    l,b=float(input()),float(input())
    ar=l*b
    print("Area of Rect=",ar)