#FileOpenEx2.py
fp=open("kvr1.data","w")
print("File Created and Opened in Write Mode")
print("Type of fp=",type(fp))