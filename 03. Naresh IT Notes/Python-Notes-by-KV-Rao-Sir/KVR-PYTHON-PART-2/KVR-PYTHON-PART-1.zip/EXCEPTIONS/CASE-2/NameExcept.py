#NameExcept.py
class InvalidNameError(Exception):pass