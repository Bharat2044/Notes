#MulExcept.py<--File Name and Module Name
class NegNumberError(Exception):pass
class ZeroError(BaseException):pass