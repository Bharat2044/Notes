#ATMMenu.py
def menu():
    s="""==========================================
		Funds Transfer / ATM Operations
==========================================
		1. Deposit
		2. Withdraw
		3. Bal Enq
		4. Exit
==========================================
    """
    print(s)

