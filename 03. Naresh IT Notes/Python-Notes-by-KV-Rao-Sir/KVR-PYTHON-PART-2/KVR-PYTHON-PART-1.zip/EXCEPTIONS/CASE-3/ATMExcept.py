#ATMExcept.py<--File Name and Module Name
class DepositError(BaseException):pass
class WithDrawError(Exception):pass
class InSuffFundError(Exception):pass