#developing Programmer Defined exception which works like ZeroDivisionError
#Except.py----File Name and Module Name--Phase-1--developing the exception
class DenDivisionError(Exception):pass

# here DenDivisionError is called Programmer-Defined Exception