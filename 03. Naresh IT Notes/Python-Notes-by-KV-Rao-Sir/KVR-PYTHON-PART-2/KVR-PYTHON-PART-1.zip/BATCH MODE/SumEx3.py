#Program for adding two numbers
a=float(input("Enter Val of a:"))
b=float(input("Enter Val of b:"))
c=a+b
print("************************")
print("val of a=",a)
print("val of b=",b)
print("sum=",c)
print("************************")
