#program for addition of Two Numbers
a=100
b=200
c=a+b
print("Val of a=",a)
print("Val of b=",b)
print("Sum=",c)
