#Program for Reading Tweo Values from KBD and Find their sum
#DataReadEx3.py
x=input("Enter First Value:")
y=input("Enter Second Values")
#Convert  x,y Values of str into  int type values
a=float(x)
b=float(y)
#compute sum
c=a+b
#Display the Output
print("------------------------------------------------")
print("First Value:{}".format(a))
print("Second Value:{}".format(b))
print("Sum={}".format(c))
print("------------------------------------------------")