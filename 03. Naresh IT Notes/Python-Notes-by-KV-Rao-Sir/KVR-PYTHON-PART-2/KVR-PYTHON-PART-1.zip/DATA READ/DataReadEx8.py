#Program for Reading Two Values from KBD and Find their sum
#DataReadEx8.py
print("Sum={}".format(float(input("Enter First Value:"))+float(input("Enter Second Value:"))))
