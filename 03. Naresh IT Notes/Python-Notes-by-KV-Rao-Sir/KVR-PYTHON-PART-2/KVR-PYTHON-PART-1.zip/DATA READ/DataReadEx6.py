#Program for Reading Two Values from KBD and Find their sum
#DataReadEx6.py
print("Enter Two Values:")
a=float(input())
b=float(input())
print("------------------------------------------------")
print("First Value:{}".format(a))
print("Second Value:{}".format(b))
print("Sum={}".format(a+b))
print("-------------------OR-----------------------------")
print("Sum({},{})={}".format(a,b,a+b))