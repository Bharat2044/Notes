#Program for Cal Area and Permiter of Rect
#RectArea.py
length=float(input("Enter Length:"))
breadth=float(input("Enter Breadth:"))
ar=length*breadth
pr=2*(length+breadth)
print("==========================")
print("Length={}".format(length))
print("Breadth={}".format(breadth))
print("Area of Rect={}".format(ar))
print("Perimeter of Rect={}".format(pr))
print("==========================")