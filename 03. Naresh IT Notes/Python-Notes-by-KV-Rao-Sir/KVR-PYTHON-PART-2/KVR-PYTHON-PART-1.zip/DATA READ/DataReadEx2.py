#Program for Reading any type of Data by giving User-Prompting Message
x=input("Enter Any Value:")
print(x,type(x))
