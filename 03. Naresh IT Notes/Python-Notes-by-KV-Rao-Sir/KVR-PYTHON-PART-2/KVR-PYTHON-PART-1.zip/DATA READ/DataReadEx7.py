#Program for Reading Two Values from KBD and Find their sum
#DataReadEx7.py
print("Enter Two Values:")
print("Sum={}".format(float(input())+float(input())))
