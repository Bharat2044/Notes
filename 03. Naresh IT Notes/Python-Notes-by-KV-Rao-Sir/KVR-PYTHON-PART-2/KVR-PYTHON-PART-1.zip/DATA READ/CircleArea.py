#Program for cal area of Circle
r=float(input("Enter Radius:"))
area=3.14*r*r
print("Radius={}".format(r))
print("Area of Circle={}".format(area))
print("-------------OR-------------------------")
print("Area of Circle=%0.2f" %area)
print("-------------OR-------------------------")
print("Area of Circle={}".format(round(area,2)))