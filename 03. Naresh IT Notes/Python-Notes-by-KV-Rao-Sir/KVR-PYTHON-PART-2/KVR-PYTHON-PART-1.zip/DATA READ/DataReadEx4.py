#Program for Reading Two Values from KBD and Find their sum
#DataReadEx4.py
a=float(input("Enter First Value:"))
b=float(input("Enter Second Value:"))
#compute sum
c=a+b
#Display the Output
print("------------------------------------------------")
print("First Value:{}".format(a))
print("Second Value:{}".format(b))
print("Sum={}".format(c))
print("------------------------------------------------")