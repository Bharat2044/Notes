#Program for Reading Two Values from KBD and Find their sum
#DataReadEx5.py
print("Enter Two Values:")
a=float(input())
b=float(input())
#Compute sum
c=a+b
#Display the Output
print("------------------------------------------------")
print("First Value:{}".format(a))
print("Second Value:{}".format(b))
print("Sum={}".format(c))
print("------------------------------------------------")