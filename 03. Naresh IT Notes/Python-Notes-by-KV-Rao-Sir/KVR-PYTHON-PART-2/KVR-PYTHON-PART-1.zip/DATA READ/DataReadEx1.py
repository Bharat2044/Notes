#Program for Reading the value and display
print("Enter Any Value:")
x=input()
print(x,type(x))

