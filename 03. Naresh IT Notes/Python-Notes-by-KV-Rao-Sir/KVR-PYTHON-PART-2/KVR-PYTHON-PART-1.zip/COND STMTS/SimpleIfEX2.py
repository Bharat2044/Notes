#Program for deciding whether the given number is +VE or -VE or Zero
#SimpleIfEX2.py
n=float(input("Enter a Number:")) # n=-40
if(n==0):
    print("{} is ZERO".format(n))
if(n>0):
    print("{} is +VE".format(n))
if(n<0):
    print("{} is -VE".format(n))
print("Program Execution Completed")
