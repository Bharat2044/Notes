#Moviee.py
tkt=input("Do u have a Ticket(yes/no):")
if(tkt=="yes"):
 print("Enter into the theater")
 print("watch the moviee")
 print("Eat Pop Corn!!!")
print("Goto Home")



