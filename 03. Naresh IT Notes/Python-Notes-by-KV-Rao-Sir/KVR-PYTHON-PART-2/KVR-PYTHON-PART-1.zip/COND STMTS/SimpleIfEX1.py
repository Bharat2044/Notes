#Program for deciding whether the given number is even or odd
#SimpleIfEX1.py
n=int(input("Enter a Number:"))
#check for even
if(n%2==0):
    print("{} is Even".format(n))
#check for odd
if(n%2!=0):
    print("{} is Odd".format(n))
print("Program Execution Completed!!!")
