package com.example.resilience4j.springbootresilience4jretry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootResilience4jRetryApplicationTests {

	@Test
	void contextLoads() {
	}

}
