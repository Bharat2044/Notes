package com.example.resilience4j.springbootresilience4jretry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootResilience4jRetryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootResilience4jRetryApplication.class, args);
	}

}
