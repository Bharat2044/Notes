package com.springboot.stock.resource;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.stock.model.Quote;
import com.springboot.stock.model.Quotes;
import com.springboot.stock.repository.QuotesRepository;


@RestController
@RequestMapping("/rest/db")
//http://localhost:8300/rest/db/vijay
public class DbServiceResource {

	Logger logger= LoggerFactory.getLogger(DbServiceResource.class);
	
	@Autowired
	private QuotesRepository quotesRepository;

	@GetMapping("/{username}")
	public List<String> getQuotes(@PathVariable("username") final String username) {
		 logger.info("DbServiceResource  getQuotes : "+username);

		return getQuotesByUserName(username);

	}
	private List<String> getQuotesByUserName(@PathVariable("username") String username){
		
		/*
		 * 
		 * Ramu ==> UserName
		 * http://localhost:8300/rest/db/vijay ==>
		 * 
		 * Step1: DB Lookup for vijay ==> 
		 *     1 vijay ICICI
		 *     2 vijay JIO
		 *     3 vijay AIRTEL
		 *     4 vijay YESBANK
		 *     
		 *     "ICICI,JIO,AIRTEL,YESBANK" ==> Output
		 *   
		 */
		return quotesRepository.findByUserName(username).// List<Quote>
				stream().map(quote -> {
										return quote.getQuote();//ICICI,JIO,AIRTEL,YESBANK
									   }).collect(Collectors.toList());
	}

	@PostMapping("/add")
	public List<String> add(@RequestBody final Quotes quotes) {
		
		/*
		 * 
		 * Input
		 {
	 *     username:"Vijay",
	 *     quotes:"ICICI,JIO,AIRTEL,YESBANK"
	 *     }
	 *     
	 *     ==>
	 *     
	 *     
	 *     Need to save to Database as below
	 *     
	 *     1 vijay ICICI
	 *     2 vijay JIO
	 *     3 vijay AIRTEL
	 *     4 vijay YESBANK
	 *     
	 *     
	 *     Output:
	 *     "ICICI,JIO,AIRTEL,YESBANK"
	 *     
	 *     
	 *     for each stock in stockcodes{
	 *      Quote quote=new Quote();
	 *      quote.setusername("Vijay");
	 *      quote.setQuoteName(stock);
	 *      quoteRepository.save(quote)
	 *      }
	 *      
	 *      ArrayLIst<String> output=new ArrayLIst<String>();
	 *      for each quote in quoteReposity.findbyUsername("vijay")
	 *      
	 *      {
	 *      output.add(quote);
	 *      }
	 *      return output;
	 *      
	 *     
		*/
		
		/*
		 *  Input:quotes
		 {
	      username:"Vijay",
	     quotes:"ICICI,JIO,AIRTEL,YESBANK"
	     }
	 *     
	 *     ==>
		 */
		
		
		
		quotes.getQuotes().stream()
		
		.map(   //ICICI ==> (vijay,"ICICI"),(vijay,"JIO"),(vijay,"AIRTEL"),(vijay,"YESBANK")
				quote -> new Quote(quotes.getUserName(), quote))
				.forEach(quote -> {
					quotesRepository.save(quote);
				});
		return getQuotesByUserName(quotes.getUserName()); 
		//return getQuotesByUserName(quotes.getUserName());
	}
	
	
	

	
    @PostMapping("/delete/{username}")
    public List<String> delete(@PathVariable("username") final String username) {

        List<Quote> quotes = quotesRepository.findByUserName(username);
        quotesRepository.deleteAll(quotes);

        return getQuotesByUserName(username);
    }
    

}
