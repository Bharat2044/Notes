package com.ashokit.inventory.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InventoryController {
	
	
	@GetMapping(value="/item")
	public String getItem(){
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
		System.out.println(" getItem Call Returned {}  "+e.getStackTrace());
		}
		return "Product TV Retruned";
	}

}
