package com.ashokit.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryDemoApplication.class, args);
	}

}
