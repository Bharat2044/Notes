package com.example.resilience4j.springresilience4jbulkhead;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringResilience4jBulkheadApplicationTests {

	@Test
	void contextLoads() {
	}

}
