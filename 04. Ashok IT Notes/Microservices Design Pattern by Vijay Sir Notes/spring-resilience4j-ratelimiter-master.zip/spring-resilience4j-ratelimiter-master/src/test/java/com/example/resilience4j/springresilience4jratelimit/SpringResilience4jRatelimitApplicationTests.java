package com.example.resilience4j.springresilience4jratelimit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringResilience4jRatelimitApplicationTests {

	@Test
	void contextLoads() {
	}

}
