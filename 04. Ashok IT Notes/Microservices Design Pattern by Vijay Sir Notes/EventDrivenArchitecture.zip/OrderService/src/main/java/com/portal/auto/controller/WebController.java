package com.portal.auto.controller;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.portal.auto.model.Order;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping(value = "/order-processing/")
public class WebController {

	@Autowired
	private AmqpTemplate amqpTemplate;

	//@Autowired
	//PaymentProcessedEvent paymentProcessedEvent;

	@PostMapping(value = "/postpayment")
	public String producer(@RequestBody Order ordObj) {
		
		
		//The below is the event where once the payment is completed we are pushing object to RabitMq

		amqpTemplate.convertAndSend("payment-exchange", "", ordObj);

		return "Message sent to the RabbitMQ Fanout Exchnage Successfully";
		//return true;
	}
	
	//localhost:8080/order-processing/postpayment ==> ordObj

	
}
