package com.portal.auto;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.MessageListenerContainer;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

	@Bean
	Queue stockQueue() {
		return new Queue("stockQueue", false);
	}

	@Bean
	Queue emailQueue() {
		return new Queue("EmailQueue", false);
	}

	@Bean
	Queue smsQueue() {
		return new Queue("SMSQueue", false);
	}

	
	@Bean
	Queue shipmentQueue() {
		return new Queue("shipmentQueue", false);
	}
	
	
	//If we want to broadcast the messages we can use FanoutExchange
	
	// Publisher only sends the messages to this workflow
	
	//RabitmQ interally sends the messages to the all queues bounded to this workflow
	@Bean
	FanoutExchange exchange() {
		return new FanoutExchange("payment-exchange");
	}
	
	
	
	
	
	
	@Bean
	Binding stockBinding(Queue stockQueue, FanoutExchange exchange) {
		return BindingBuilder.bind(stockQueue).to(exchange);
	}

	@Bean
	Binding emailBinding(Queue emailQueue, FanoutExchange exchange) {
		return BindingBuilder.bind(emailQueue).to(exchange);
	}

	
	@Bean
	Binding smsBinding(Queue smsQueue, FanoutExchange exchange) {
		return BindingBuilder.bind(smsQueue).to(exchange);
	}
	
	
	@Bean
	Binding shipmentBinding(Queue shipmentQueue, FanoutExchange exchange) {
		return BindingBuilder.bind(shipmentQueue).to(exchange);
	}
    
	
	@Bean
	MessageListenerContainer messageListenerContainer(ConnectionFactory connectionFactory) {
		SimpleMessageListenerContainer simpleMessageListenerContainer = new SimpleMessageListenerContainer();
		simpleMessageListenerContainer.setConnectionFactory(connectionFactory);
		return simpleMessageListenerContainer;
	}
    
	@Bean
	public MessageConverter jsonMessageConverter() {
		return new Jackson2JsonMessageConverter();
	}

	
	
	
	
	
	
	public AmqpTemplate  rabbitTemplate(ConnectionFactory connectionFactory) {
		final RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
		rabbitTemplate.setMessageConverter(jsonMessageConverter());
		return rabbitTemplate;
	}
	
	
	/*
	@Bean
	FanoutExchange stockexchange() {
		return new FanoutExchange("stock-exchange");
	}
	

	@Bean
	Binding stockBinding(Queue stockQueue, FanoutExchange stockexchange) {
		return BindingBuilder.bind(stockQueue).to(stockexchange);
	}
	
	*/
}
