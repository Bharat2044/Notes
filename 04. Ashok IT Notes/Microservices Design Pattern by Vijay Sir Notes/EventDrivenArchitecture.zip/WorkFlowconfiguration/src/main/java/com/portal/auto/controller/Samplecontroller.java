package com.portal.auto.controller;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.portal.auto.model.Order;

@RestController
@RequestMapping(value="/workflow")
public class Samplecontroller {
	
	

	@Autowired
	private AmqpTemplate amqpTemplate;

	
	@PostMapping(value = "/postpayment")
	public String producer( ) {

		
		Order ordObj=new Order("1","test","test","test","test","aaa");
		
		//Here we will only mention WorkFlow(Exchange Name) 
		amqpTemplate.convertAndSend("payment-exchange", "", ordObj);

		return "Message sent to the RabbitMQ Fanout Exchnage Successfully";
		//return true;
	}
	

}
