package com.portal.auto.controller;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.portal.auto.model.Order;

@Component
@RabbitListener(queues = "SMSQueue")
public class PaymentReceivedEvent {

	
	@RabbitHandler
    public void receiveMessage(Order order) {
		 System.out.println("Sucessfully Sent SMS To Customer for the Order Id <" + order.getOrderId()+ ">  Mobile Number <" + order.getMobileNumber() + ">  ");
	        
	       
        
        // do some processing for Stock Processing
        
        
    }

}
