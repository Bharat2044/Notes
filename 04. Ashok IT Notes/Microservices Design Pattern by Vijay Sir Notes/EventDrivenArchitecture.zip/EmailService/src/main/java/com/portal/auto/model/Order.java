package com.portal.auto.model;

public class Order {
	
	
	private String orderId;
	private String emailId;
	private String prodId;
	private String mobileNumber;
	private String shipper;
	private String shipmentStatus;
	private String zipCode;
	
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getProdId() {
		return prodId;
	}
	public void setProdId(String prodId) {
		this.prodId = prodId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getShipper() {
		return shipper;
	}
	public void setShipper(String shipper) {
		this.shipper = shipper;
	}
	
	public String getShipmentStatus() {
		return shipmentStatus;
	}
	public void setShipmentStatus(String shipmentStatus) {
		this.shipmentStatus = shipmentStatus;
	}
	public Order(String orderId, String emailId, String prodId, String mobileNumber, String shipper,
			String shipmentStatus) {
		super();
		this.orderId = orderId;
		this.emailId = emailId;
		this.prodId = prodId;
		this.mobileNumber = mobileNumber;
		this.shipper = shipper;
		this.shipmentStatus = shipmentStatus;
	}
	
	
	
	public Order(String orderId, String emailId, String prodId, String mobileNumber, String shipper,
			String shipmentStatus, String zipCode) {
		super();
		this.orderId = orderId;
		this.emailId = emailId;
		this.prodId = prodId;
		this.mobileNumber = mobileNumber;
		this.shipper = shipper;
		this.shipmentStatus = shipmentStatus;
		this.zipCode = zipCode;
	}
	public Order() {}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", emailId=" + emailId + ", prodId=" + prodId + ", mobileNumber="
				+ mobileNumber + ", shipper=" + shipper + ", shipmentStatus=" + shipmentStatus + "]";
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
	
	
	
	

}
