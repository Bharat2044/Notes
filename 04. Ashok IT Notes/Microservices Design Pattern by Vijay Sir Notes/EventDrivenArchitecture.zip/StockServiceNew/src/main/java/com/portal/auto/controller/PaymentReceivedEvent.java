package com.portal.auto.controller;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.portal.auto.model.Order;

@Component
//The following annotation will listen to StockQueue , if any new message comes to StockQueu then thin annotation will pick the data
@RabbitListener(queues = "stockQueue")
public class PaymentReceivedEvent {

	
	@RabbitHandler
	//Once them item is picked ==> RabiitHandler will call the receiveMessage
    public void receiveMessage(Order order) {
        System.out.println("Sucessfully Processed Stock Update for the Order Id <" + order.getOrderId()+ ">  Product Id <" + order.getProdId()+ ">  ");
        
        // do some processing for Stock Processing
        
        //update order set inventory=inventory-orderobj.getInventory() where order_id=order.getOrderId();
        
        
    }

}
