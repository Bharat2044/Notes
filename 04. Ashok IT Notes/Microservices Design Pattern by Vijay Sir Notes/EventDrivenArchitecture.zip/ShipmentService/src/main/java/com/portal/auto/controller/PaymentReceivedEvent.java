package com.portal.auto.controller;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.portal.auto.model.Order;

@Component
@RabbitListener(queues = "shipmentQueue")
public class PaymentReceivedEvent {

	@Autowired
	private AmqpTemplate amqpTemplate;

	@RabbitHandler
	public void receiveMessage(Order order) {
		System.out.println("Sucessfully Stated Shipment Service for the Order Id <" + order.getOrderId()
				+ ">  Customer Zip Code <" + order.getZipCode() + ">  ");

		
		/*
		
		if (order.getShipmentStatus() == "SHIPPED") {

			amqpTemplate.convertAndSend("stock-exchange", "", order);
		}*/
		

		// do some processing for Stock Processing

	}

}
