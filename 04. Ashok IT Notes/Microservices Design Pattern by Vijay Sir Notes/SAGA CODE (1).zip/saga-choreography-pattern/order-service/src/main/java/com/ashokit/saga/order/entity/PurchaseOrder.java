package com.ashokit.saga.order.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import com.ashokit.saga.commons.event.OrderStatus;
import com.ashokit.saga.commons.event.PaymentStatus;

@Entity
@Table(name = "PURCHASE_ORDER_TBL")

public class PurchaseOrder {
    @Id
    @GeneratedValue
    private Integer id;
    private Integer userId;
    private Integer productId;
    private Integer price;
    @Enumerated(EnumType.STRING)
    private OrderStatus orderStatus;
    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public OrderStatus getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}
	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public PurchaseOrder(Integer id, Integer userId, Integer productId, Integer price, OrderStatus orderStatus,
			PaymentStatus paymentStatus) {
		super();
		this.id = id;
		this.userId = userId;
		this.productId = productId;
		this.price = price;
		this.orderStatus = orderStatus;
		this.paymentStatus = paymentStatus;
	}
	public PurchaseOrder() {}
	@Override
	public String toString() {
		return "PurchaseOrder [id=" + id + ", userId=" + userId + ", productId=" + productId + ", price=" + price
				+ ", orderStatus=" + orderStatus + ", paymentStatus=" + paymentStatus + "]";
	}
	
	
    
    
}
