package com.ashokit.saga.payment.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class UserBalance {
    @Id
    private int userId;
    private int price;
    
    
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public UserBalance(int userId, int price) {
		super();
		this.userId = userId;
		this.price = price;
	}
    
    
	public UserBalance() {}
	@Override
	public String toString() {
		return "UserBalance [userId=" + userId + ", price=" + price + "]";
	}
	
	
}
